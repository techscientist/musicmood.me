window.setTimeout(function(){
    $('.moods').addClass('hide');
    $('input').addClass('hide');
    setTimeout(function() {
        $('.music').addClass('show');
      }, 1000);
    setTimeout(function(){
        $('input').addClass('show').removeClass('hide').delay(5000);
    }, 2200);
}, 3000);

$( "input" ).focus(function() {
    $('.musiclist').addClass('show');
});
$( "input" ).focusout(function() {
    $('.musiclist').removeClass('show').addClass('hide');
});
$( ".musiclist li" ).on('click',function() {
   $('.music').removeClass('show').addClass('hide');
   setTimeout(function() {
        $('.moodfinal').addClass('show');
    }, 500);
});
